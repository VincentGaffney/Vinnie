Salutations .
![AshAshFoxGIF](https://github.com/user-attachments/assets/849c7dfb-524a-4dd5-9877-8882e3bca702)
Cis Male    ///    bisexual aroace oriented    ///    queer platonic    .
